package com.bank.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bank.entities.Transaction;
import com.bank.service.BankService;
public class BankUi {


	public static void main(String[] args) {

		Scanner sc  = new Scanner(System.in);      
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		BankService bankService =  context.getBean("bankService",BankService.class);
		String enter;
		int c,balance;
		String name,password,phoneNo;

		while(true)
		{
			System.out.println("---------------------------");

			System.out.println("1.Create account");
			System.out.println("2.Show balance");
			System.out.println("3.Deposit amount");
			System.out.println("4.Withdraw amount");
			System.out.println("5.Fund transfer");
			System.out.println("6.Mini Statement");
			System.out.println("7.Exit");
			System.out.println("\nPlease Enter Your choice : ");
			enter = sc.next();

			if(enter.matches("[a-z]*")||enter.matches("[A-Z]*")){	     
				System.out.println("Please Enter A Valid Choice!!!");
				main(null);
			}
			switch (enter) {
			case "1":
				System.out.println("Payments Wallet Bank");
				do{
					System.out.println("Enter Your Name : ");
					name = sc.next();
					c =bankService.nameValidate(name);
				}while(c!=1);
				
				do{
					System.out.println("Enter Your Phone Number : ");
					phoneNo = sc.next();
					c = bankService.mobNoValidate(phoneNo);
				}while(c!=1);

				long phone = Long.parseLong(phoneNo);
				long accountNo = phone + 1;

				do{
					System.out.println("Enter Password : ");
					password = sc.next();
					c = bankService.passwordValidate(password);
				}while(c!=1);

				balance = 10000;
				boolean result =  bankService.createAccount(name,phoneNo,password,accountNo,balance);
				if(result){
					System.out.println("Account created successfully \n Your Account No is : "+accountNo);
				}break;

			case "2":

				System.out.println("Please Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Please Enter Password : ");
				password = sc.next();
				boolean b1= bankService.validateAccount(accountNo,password);
				if(b1){
					balance = bankService.showBalance(accountNo);
					if(balance!=0){
						System.out.println("Your Available Balance is: "+balance);
					}
					else{
						System.out.println("Please Try Again Later");
					}
				}else{
					System.out.println("Please Enter A Valid Credentials");
				}

				break;
				
			case "3":
				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				boolean b= bankService.validateAccount(accountNo,password);
				if(b)
				{
					System.out.println("Enter amount to Deposit in the Account : ");
					int deposit = sc.nextInt();
					balance = bankService.depositAmount(accountNo,deposit);
					System.out.println("Amount Deposited Successfully :-)\n");
					System.out.println("Your Balance After Deposit is : "+balance);
				}
				else{
					System.out.println("Please Enter a Valid Credentials");
				}
				break;
				
			case "4":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= bankService.validateAccount(accountNo,password);
				if(b){
					balance = bankService.showBalance(accountNo);
					System.out.println("Your Current Balance: "+balance);
					System.out.println("Enter Amount for Withdrawn: ");
					int withdraw = sc.nextInt();
					balance = bankService.withdrawAmount(accountNo,withdraw);
					if(balance>=0){
						System.out.println("Amount Withdrawn Successfully\n");
						System.out.println("Your Balance After Withdrawl is: "+balance);
					}
					else{
						System.out.println("Funds Are Not Sufficient");
					}
				}


				else{
					System.out.println("Please Enter A Valid Credentials");
				}
				break;

			case "5":

				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password: ");
				password = sc.next();
				b= bankService.validateAccount(accountNo,password);
				if(b){
					System.out.println("\n Please Enter Account Number to Transfer the Funds");
					long  accno = sc.nextLong();
					System.out.println("Enter Amount to Make Fund Transfer :");
					int amount = sc.nextInt();
					boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
					if(transfer){
						System.out.println("Transaction is Completed Sucessfully \n");
					}
					else{
						System.out.println("Something went Wrong. Please Wait for Sometime");
					}
				}
				else{
					System.out.println("Please Enter A Valid Credantials");
				}

				break;
			case "6":
				System.out.println("Enter Account Number : ");
				accountNo = sc.nextLong();
				System.out.println("Enter Password : ");
				password = sc.next();
				b= bankService.validateAccount(accountNo,password);
				if(b){
					List<Transaction> trans=bankService.getTransaction(accountNo);

					System.out.println("****Mini Statement****\n");

					for(Transaction tran:trans){
						System.out.println(tran);
					}

				}
				else {
					System.out.println("Please Enter a Valid Credantials");
				}
				break;

			case "7": 
				System.out.println("Thank You for Using the Application");
				System.exit(0);
			}

		}

	}

}
